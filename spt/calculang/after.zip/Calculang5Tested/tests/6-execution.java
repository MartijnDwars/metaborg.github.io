
public class example {
  public static void main(String[] args) {
    System.out.println(42);
    System.exit(0);
  }
}
